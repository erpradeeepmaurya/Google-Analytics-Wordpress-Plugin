<?php

global $wpdb;
$position=get_option('wppm_ga_option');
$gacode=get_option('wppm_ga_code');

function wppm_analytics_code($gacode) {

global $gacode;
  ?>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', '<?php echo $gacode; ?>', 'auto');
  ga('send', 'pageview');

</script>
  <?php
 
}


	
if($position=="footer"){
add_action( 'wp_footer', 'wppm_analytics_code', 10,1 );
 	
}else{
	
	add_action( 'wp_head', 'wppm_analytics_code', 10,1 );
	
}


?>