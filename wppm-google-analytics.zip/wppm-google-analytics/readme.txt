=== Google Analytics Wordpress Plugin ===
Contributors: Pradeep Maurya
Donate link: https://www.paypal.me/pradeeprkt
Tags: google analytic wordpress plugin, wp google analytic, google analytic, google analytic in header, google analytic in footer, insert google analytic in all pages, add google analytic, analytic wordpress plugin, google analytic module
Requires at least: 3.5.1
Tested up to: 4.9.4
Stable tag: 2.0.0
Last Updated: 2018-Feb-10
Plugin Name: Google Analytics Wordpress Plugin
Plugin URI: https://wordpress.org/plugins/wppm-google-analytics/
Author URI: http://www.pradeepmaurya.in/about-me
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The Google Analytics wordpress plugin enable google analytics to all pages. Allow to find out how your visitors locate your website.

== Description ==

The Google Analytics wordpress plugin enable google analytics to all pages. Allow to find out how your visitors locate your website. Able to identify which pages and links your visitors click the most.

<h4>Features</h4>
    
* Easy to Install 
* Easy to use
* Easy to Configure Google Analytics Tracking Code

If you want more information about this plugin or another one don't doubt to visit our website:

[http://www.pradeepmaurya.in/](http://www.pradeepmaurya.in/ "Pradeep Maurya")

= Technical Support =

If any problem occurs, please contact us at [support@pradeepmaurya.in](mailto:support@pradeepmaurya.in).

== Installation ==

1. Upload the directory `/wppm-google-analytics/` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click on "WPPM Google Analytics Settings" menu and insert your analytic code with header and footer position.

== Frequently Asked Questions ==

If you facing any problem please create a topic.


== Upgrade Notice ==
According to requirment of plugin and user feedback. We will upgrade this plugin.


== Screenshots ==
1. Plugin menu in admin menu.
2. Setting page of the plugin.

== Changelog ==
=2.0.0
*This is the second version

= 1.0.0
* This is the first version